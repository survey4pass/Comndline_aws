#!/bin/bash
export PATH=$PATH:/usr/local/bin
cd /opt/ec2-launch-scripts/vpc2w2_QA_ops/start_stop_instances/control

#generate the list of instances to start up and create a script to execute the commands
./get_stopped_instances_to_start.sh 

#start the stopped instances
./execute-stopped-instances-to-running.sh 

#wait for instances to reach running state and be responsive
sleep 360

#execute script to loop through app tiers in order and start applications
./start-ng-apps.sh 
sleep 30

#This part no longer required because instances remain associated with ELB across instance stop/start
#sleep 60
#./start-all-elb.sh 

#start cron on the database tier
for i in  `cat ../../ng-cluster/ng_mysqlgrid_cssh_hosts`; do ssh $i "sudo /etc/init.d/cron start"; done
#restart ganglia clients to cover any app-related issues
for i in `cat ../../ng-cluster/ng_all_cssh_hosts`; do ssh $i "sudo /etc/init.d/ganglia-monitor restart"; done
