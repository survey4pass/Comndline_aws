#!/bin/bash
export PATH=$PATH:/usr/local/bin
cd /opt/ec2-launch-scripts/vpc2w2_QA_ops/start_stop_instances/control

#generate list of instances to stop
./get_running_instances_to_stop.sh

#if services needed to be stopped in order, that logic would go here

#stop instances
./execute-running-instances-to-stop.sh 

#stop cron on database server since the regular scheduled jobs aren't relevant when the environment is down
for i in  `cat ../../ng-cluster/ng_mysqlgrid_cssh_hosts`; do ssh $i "sudo /etc/init.d/cron stop"; done
