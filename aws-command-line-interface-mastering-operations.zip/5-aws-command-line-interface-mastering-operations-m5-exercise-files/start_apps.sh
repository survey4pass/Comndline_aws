#!/bin/bash
export DEBIAN_FRONTEND=noninteractive

case `hostname` in
*app1*) mkdir -p /mnt/ephemeral/log/nginx/
	/etc/init.d/nginx start
	;;
*app2*) mkdir /mnt/ephemeral/logs
 	cd /opt/ubermedia/adplatform/api
	./start-module.sh
        ;;
*app3*) cd /opt/ubermedia/adplatform/uberads-ui/
	./start-ruby.sh
	;;
*app4*) service cron start
	dpkg-reconfigure ad-request-config
	dpkg-reconfigure ad-request
	/usr/bin/nice -n 10 perl /opt/ubermedia/adplatform/data/url-categories-download.pl --cluster qa1204 --s3cmd-config /etc/ubermedia/adplatform/request/s3cfg --path /mnt/ephemeral/adplatform/request/url-categories.tsv
	cd /opt/ubermedia/adplatform/request
	./start-module.sh
        ;;
*app5*) mkdir /mnt/ephemeral/logs
	cd /opt/ubermedia/adplatform/consumer/budget
	./start-module.sh
        ;;
*app6*) mkdir /mnt/ephemeral/mysql-tmp
	chown mysql:mysql /mnt/ephemeral/mysql-tmp 
	/etc/init.d/mysql.server start
	mkdir /mnt/ephemeral/logs
	cd /opt/ubermedia/adplatform/consumer/grid
	./start-module.sh
        ;;
*app7*) mkdir /mnt/ephemeral/logs
	cd /opt/ubermedia/adplatform/consumer/log
	./start-module.sh
        ;;
*app8*) mkdir -p /mnt/ephemeral/log/nginx/
	/etc/init.d/nginx start
	;;
esac

