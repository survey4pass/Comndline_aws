#!/bin/bash

REGION=$1
AMI=$2
today=`/bin/date +%Y%m%d%H%M`

/usr/local/bin/aws --region $REGION ec2 create-image --instance-id $AMI --name $AMI\_$today
