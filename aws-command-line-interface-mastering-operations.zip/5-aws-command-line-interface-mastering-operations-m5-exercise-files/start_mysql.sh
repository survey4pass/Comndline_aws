#!/bin/bash
mkdir /mnt/ephemeral/mysql-tmp
chown mysql:mysql /mnt/ephemeral/mysql-tmp 
/etc/init.d/mysql.server start
