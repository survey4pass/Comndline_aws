#!/bin/bash

#Perform instance inventory for all required properties to avoid long-running commands later
aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[join(`,`,Tags[?Key==`Name`].Value),InstanceId,State.Name,PublicDnsName,PrivateDnsName,PrivateIpAddress]' --filter Name=tag:Name,Values=vpc2w2-ng-*qa* Name=instance-state-code,Values=16 > cssh_hosts.base


#Create single file for cssh purposes
cat cssh_hosts.base|grep vpc2w2-ng-|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_all_cssh_hosts


#Create individual files per application tier for use by environment stop/start scripts
cat cssh_hosts.base|grep vpc2w2-ng-qa-appapi|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_appapi_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-appcms|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_appcms_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-apple|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_apple_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-consb|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_consb_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-consg|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_consg_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-consl|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_consl_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-conso|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_conso_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-mdbcache|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_mdbcache_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-mdbgrid|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_mdbgrid_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-mysqlcore|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_mysqlcore_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-mysqlgrid|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_mysqlgrid_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-rmqexqu|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_rmqexqu_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-servefrontend|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_servefrontend_cssh_hosts
cat cssh_hosts.base|grep vpc2w2-ng-qa-twittercrawl|cut -f4 >  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_twittercrawl_cssh_hosts

