#!/bin/bash
# takes three arguments: ami basename, region, and number of ami to keep

OLDIFS=$IFS
IFS=$' '
while getopts ":a:r:n:" option
do
        case $option in
                a) AMINAME=${OPTARG};;
                r) REGION=${OPTARG};;
                n) NUMKEEP=${OPTARG};;
        esac
done

IFS=$OLDIFS
TAIL=$(( $NUMKEEP + 1 ))

echo "aminame is $AMINAME"
echo "region is $REGION"
echo "numkeep is $NUMKEEP"

#generate list of AMI IDs ordered by date, except for the most recent NUMKEEP images
AMIIDS=`/usr/local/bin/aws ec2 describe-images --region $REGION --owners self --filters "Name=name,Values=$AMINAME*" --output text --query Images[*].[ImageId,CreationDate] |sort -r -k2 |cut -f1 |tail -n +$TAIL`

if [ "$AMIIDS" != "" ]; then

  #loop through all AMI IDs
  for AMI in $AMIIDS; do

    # generate a list of snapshots associated with each AMI ID
    SNAPSHOTS=`/usr/local/bin/aws ec2 describe-images --region $REGION --owners self --filters "Name=image-id,Values=$AMI" --output text --query Images[*].BlockDeviceMappings[*].Ebs[].SnapshotId |tr -s '\t' '\n'`

    # deregister the AMI
    echo "Deleting AMI $AMI"
    aws ec2 deregister-image --region $REGION --image-id $AMI

    # loop through all snapshots associated with the AMI and delete them
    for i in $SNAPSHOTS; do
      echo "deleting snapshot $i"
      aws ec2 delete-snapshot --region $REGION --snapshot-id $i
    done
  done
else
  echo "Not enough images, exiting"
fi

