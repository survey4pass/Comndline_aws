#!/bin/bash

FN1=`mktemp /tmp/ec2-instances.XXX`
FN2=`mktemp /tmp/ec2-instances2.XXX`

rm -f execute-stopped-instances-to-run.sh

aws ec2 describe-instances --output text --query 'Reservations[*].Instances[*].[join(`,`,Tags[?Key==`Name`].Value),InstanceId,ImageId,RootDeviceType,InstanceType,State.Name,PublicDnsName,PrivateDnsName,PrivateIpAddress]' --filter Name=tag:Name,Values=vpc2w2-ng-qa* Name=instance-state-code,Values=80 > $FN1

DATAFILE=$FN1
for machine in `cat $DATAFILE |cut -f2`; do
info=`grep $machine $DATAFILE |cut -f1`
case $info in
        *mysqlgrid*) 
        ;;
        *mysqlcore*)
        ;;
	*consg*)
	;;
	*) echo -e "aws ec2 start-instances --instance-ids " "$machine" "\t" "# $info" >> $FN2 
	;;
esac
done

cat  $FN2   |sort -k6 > execute-stopped-instances-to-run.sh
chmod 775 execute-stopped-instances-to-run.sh

rm -f $FN1 $FN2
