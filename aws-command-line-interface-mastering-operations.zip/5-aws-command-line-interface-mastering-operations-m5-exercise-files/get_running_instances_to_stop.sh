#!/bin/bash

FN1=`mktemp /tmp/ec2-instances.XXX`

rm -f execute-running-instances-to-stop.sh

DATAFILE="/opt/ec2-launch-scripts/vpc2w2_QA_ops/cssh_hosts.base"
for machine in `cat $DATAFILE |cut -f2`; do
info=`grep $machine $DATAFILE |cut -f1`
case $info in
        *mysqlgrid*) 
        ;;
        *mysqlcore*)
        ;;
	*consg*)
	;;
	*) echo -e "aws ec2 stop-instances --instance-ids " "$machine" "\t" "# $info" >> $FN1 
	;;
esac
done

cat  $FN1   |sort -k6 > execute-running-instances-to-stop.sh
chmod 775 execute-running-instances-to-stop.sh

rm -f $FN1
