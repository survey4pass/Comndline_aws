sudo pip install virtualenv
mkdir ~/build
virtualenv /home/ec2-user/build/
cd build
source ./bin/activate
sudo yum install gcc openssl-devel python-devel libffi-devel
pip install pycrypto
pip install paramiko

