import boto3
import paramiko
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
def worker_handler(event, context):

    logger.error("Creating s3 client")
    s3_client = boto3.client('s3')
    #Download private key file from secure S3 bucket
    logger.error("Connecting to s3 for key file")
    s3_client.download_file('lambda-db-backups','keys/csmithaws.pem', '/tmp/csmithaws.pem')

    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    host=event['IP']
    print "Connecting to " + host
    logger.error("Connecting to " + host)
    c.connect( hostname = host, username = "ec2-user", key_filename = "/tmp/csmithaws.pem" )
    print "Connected to " + host

    commands = [
	 "touch /tmp/hi_there`date`"
#        I can add other commands here which will all be executed on the remote hosts
        ]
    for command in commands:
        print "Executing {}".format(command)
        stdin , stdout, stderr = c.exec_command(command)
        print stdout.read()
        print stderr.read()

    return
    {
        'message' : "Script execution completed. See Cloudwatch logs for complete output" + host
    }
