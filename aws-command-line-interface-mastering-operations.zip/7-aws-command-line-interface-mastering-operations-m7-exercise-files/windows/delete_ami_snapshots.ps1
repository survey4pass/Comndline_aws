# Date search criteria
$dateToday = [DateTime]::Now
$daysBack = 20
$searchDate = $dateToday.AddDays(-$daysBack)
 
 
$instanceAMIs = @()
$amiCollection = {$instanceAMIs}.Invoke()
$volumeSnapshots = @()
$snapshotCollection = {$volumeSnapshots}.Invoke()
 
# Get a list of AMIs
$server_images = Get-EC2Image -Owner "self"
 
# Search for AMIs by date and add anything older than the search date
foreach ($ami in $server_images) {  
    if ([DateTime]::Compare($searchDate, $ami.CreationDate) -gt 0) {
        $amiCollection.Add($ami.ImageId)
    }
}
 
#Locate all snapshots associated with the AMIs
foreach ($amiID in $amiCollection) {
    $instanceImage = Get-EC2Image $amiID
    $snapshotCount = $instanceImage.BlockDeviceMapping.Count
     
    for ($i=0; $i -lt $snapshotCount; $i++) {
        $snapshotID = $instanceImage[0].BlockDeviceMapping[$i].Ebs | foreach {$_.SnapshotId}
        $snapshotCollection += $snapshotID
    }
}
 
# Deregister each of the AMI's in the AMI collection
foreach ($amiID in $amiCollection) {
    Unregister-EC2Image $amiID
}
 
 
# Delete each snapshot in the snapshot collection
foreach ($snapshotID in $snapshotCollection) {
    Remove-EC2Snapshot $snapshotID
}
