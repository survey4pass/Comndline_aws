import boto3
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def trigger_handler(event, context):
    #Get IP addresses of EC2 instances
    client = boto3.client('ec2')
    instDict=client.describe_instances(
            Filters=[{'Name':'tag:environment','Values':['stage']}]
        )
    hostList=[]
    for r in instDict['Reservations']:
        for inst in r['Instances']:
            hostList.append(inst['PrivateIpAddress'])

    #Invoke worker function for each IP address
    client = boto3.client('lambda')
    logger.error("Getting ready to loop through host list")
    for host in hostList:
        print "Invoking worker_function on " + host
        logger.error("Invoking worker_function on " + host)
        invokeResponse=client.invoke(
            FunctionName='worker_function',
            InvocationType='Event',
            LogType='Tail',
            Payload='{"IP":"'+ host +'"}'
        )
        print invokeResponse

    return{
        'message' : "Trigger function finished plus info logs"
    }

