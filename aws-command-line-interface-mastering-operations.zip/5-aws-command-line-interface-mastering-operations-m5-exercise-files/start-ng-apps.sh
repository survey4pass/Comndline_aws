#/bin/bash
rm -f ng-mysql-hosts-to-start.txt
rm -f ng-hosts-to-start.cssh

#ignore database servers, as they are not stopped during environment shutdown
#cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_mysqlcore_cssh_hosts > ng-mysql-hosts-to-start.txt
#cat  /opt/ec2-launch-scripts/vpc2w2_STAGE_ops/ng-cluster/ng_mysqlgrid_cssh_hosts >>  ng-mysql-hosts-to-start.txt

#ignore grid consumer, as it contains local mysql instances and is not stopped during environment shutdown
#cat  /opt/ec2-launch-scripts/vpc2w2_STAGE_ops/ng-cluster/ng_consg_cssh_hosts >> ng-hosts-to-start.cssh

cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_consl_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_appapi_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_appcms_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_consb_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_conso_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_rmqexqu_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_apple_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_servefrontend_cssh_hosts >> ng-hosts-to-start.cssh
cat  /opt/ec2-launch-scripts/vpc2w2_QA_ops/ng-cluster/ng_twittercrawl_cssh_hosts >> ng-hosts-to-start.cssh

#uncomment if there are any mysql instances that require regular startup
#for i in `cat ./ng-mysql-hosts-to-start.txt`; do ssh $i "sudo /opt/scripts/start_mysql.sh"; done

#loop through list of public dns names and start applications in order they were added to the cssh text file
for i in `cat ./ng-hosts-to-start.cssh`; do ssh $i "sudo /opt/scripts/start_apps.sh"; done
